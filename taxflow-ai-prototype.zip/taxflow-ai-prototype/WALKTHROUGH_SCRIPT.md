# 5–7 Minute Video Walkthrough Script

Use this as narration. Speak naturally; do not read every sentence word for word.

## Opening — 30 seconds

“Hi, I’m Tejaswi. I built TaxFlow AI, a clickable greenfield prototype for a client and CPA tax platform. I focused the implementation on the frontend because the case study asks us to demonstrate interaction design, information architecture, usability, and trust in AI. All tax data, documents, calculations, users, and AI outputs are simulated.”

## 1. Actionable dashboard — 45 seconds

“This is the preparer dashboard. Instead of leading with charts, it answers one question: what should I work on right now? The queue ranks work using deadline pressure, workflow blockage, tax risk, and whether the current user can act. Each item explains why it is urgent and identifies the next owner. I can open the highest-priority return directly from the queue.”

Click **Open top priority**.

## 2. Source-document traceability — 90 seconds

“This is the return review workspace for Morgan & Lee Consulting. The header shows the shared status, the specific blocker, the next action, and who owns it.

On the left are return fields. When I choose Contract labor, the center pane opens the exact supporting document and highlights the relevant source value. On the right, I see the return value, source value, document and page, extraction confidence, transformation steps, the AI explanation, and the remaining uncertainty.

This creates a complete evidence chain from return field to source and calculation. The reviewer does not need to trust a black box or manually re-derive every number.”

Click **Contract labor** in the left pane.

## 3. Trustworthy AI and correction — 75 seconds

“The AI does not simply show a confidence score. It explains what it recommends, why, what evidence supports it, and what remains uncertain. The reviewer can accept the result, correct it, ask the client, or dismiss it.

I’ll open Correct. The original AI output remains in the audit trail, while the human correction is routed for approval. This allows people to fix the AI without leaving the workflow or destroying traceability.”

Click **Correct**, show the modal, then click **Save correction**.

“High-impact and low-confidence items remain human decisions. The prototype simulates the AI; the interaction model is the deliverable.”

## 4. Status and progress — 40 seconds

Click **Status & progress**.

“Status is modeled as a shared state with entry and exit criteria. The client sees plain-language milestones, the blocker, and who must act next. Internal risk scoring and reviewer assignments can remain staff-only. This prevents labels such as ‘in progress’ from meaning different things to different users.”

## 5. Contextual collaboration — 60 seconds

Open **Collaboration** from the navigation.

“Communication is attached to a tax issue instead of becoming another generic inbox. This conversation is linked to Contract labor, Line 11. Client-visible messages and internal notes are visually distinct. The thread also shows who owns the next action. From here I can return to the linked field without losing context.”

Click **Open linked field**, then return to Collaboration if needed.

## 6. First-time client experience — 45 seconds

Use the top-right role menu and select **Individual Client**.

“The same product adapts to a client role. A new client immediately sees one prominent next action, the expected time, due date, progress, and what happens later. Less relevant functionality is deferred. Completing a task updates progress and tells the tax team that the client has acted.”

Click **Start** or check a task.

## 7. Complexity and role-aware product — 45 seconds

Open **My documents** or switch back to **Tax Preparer**, then open **Documents**.

“To test scale rather than a small happy path, the prototype generates 260 mock documents. Users can search, filter by review state and type, move through pages, and open details. The product uses progressive disclosure so dense professional information is available without overwhelming occasional users.”

Switch to **Firm Administrator**.

“The role switcher demonstrates six contexts in one cohesive product. Navigation, permissions, and actions change, but the visual language and object model stay consistent. A firm employee can also switch to a personal-return context without mixing firm and personal data.”

## Closing — 20 seconds

“The frontend interactions are genuinely wired up in local browser state. OCR, tax calculations, AI inference, messaging delivery, storage, authentication, e-signature, and filing are simulated. I chose this scope so the prototype could demonstrate the full end-to-end experience and the design decisions the case study evaluates. Thank you.”
